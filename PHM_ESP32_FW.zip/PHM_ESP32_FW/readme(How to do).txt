step 1. Connect ESP32 with Raspberry Pi by USB

step 2. Open command line

step 3. Input follow:
chmod 777 /home/pi/PHM_ESP32_FW/esp32_upload.sh
/home/pi/PHM_ESP32_FW/esp32_upload.sh

step 4. Press BOOT button of ESP32 board when blue LED flashing.