#!/bin/bash
#create at 2020/08/25

selfPath=$(dirname "$(readlink -f "$0")")
cd $selfPath

port=$(ls /dev/ttyUSB*)
addr_e000=boot_app0.bin
addr_1000=bootloader_qio_80m.bin
addr_10000=ESP32_slave_buffer_soft_trigger.ino.bin
addr_8000=ESP32_slave_buffer_soft_trigger.ino.partitions.bin

echo "Edit from Etao."
echo "Use port is "${port}
python tool.py --chip esp32 --port ${port} --baud 921600 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 80m --flash_size detect 0xe000 ${addr_e000} 0x1000 ${addr_1000} 0x10000 ${addr_10000} 0x8000 ${addr_8000}
sleep 3


# File --> Preferences --> check compilation and upload
# 0xe000
# /home/pi/.arduino15/packages/esp32/hardware/esp32/1.0.4/tools/partitions/boot_app0.bin
# 0x1000
# /home/pi/.arduino15/packages/esp32/hardware/esp32/1.0.4/tools/sdk/bin/bootloader_qio_80m.bin
# 0x10000
# /tmp/arduino_build_312291/ESP32_slave_buffer_soft_trigger.ino.bin
# 0x8000
# /tmp/arduino_build_312291/ESP32_slave_buffer_soft_trigger.ino.partitions.bin 
